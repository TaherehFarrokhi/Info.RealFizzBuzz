namespace RealFizzBuzz.Core.SequenceItemGenerators
{
    public class FizzBuzzSequenceItemGenerator : ISequenceItemGenerator
    {
        private readonly ISequenceItemGenerator _nextGenerator;

        public FizzBuzzSequenceItemGenerator()
        {
            _nextGenerator = new BuzzSequenceItemGenerator();
        }
        public string Generate(int number)
        {
            if (number % 5 == 0 && number % 3 == 0) 
                return "FizzBuzz";
            
            return _nextGenerator.Generate(number);
        }
    }
}