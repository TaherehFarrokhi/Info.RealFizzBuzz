namespace RealFizzBuzz.Core.SequenceItemGenerators
{
    public class NumberSequenceItemGenerator : ISequenceItemGenerator
    {
        public string Generate(int number)
        {
            return number.ToString();
        }
    }
}