namespace RealFizzBuzz.Core.SequenceItemGenerators
{
    public class FizzSequenceItemGenerator : ISequenceItemGenerator
    {
        private readonly ISequenceItemGenerator _nextGenerator;

        public FizzSequenceItemGenerator()
        {
            _nextGenerator = new NumberSequenceItemGenerator();
        }
        
        public string Generate(int number)
        {
            return number % 3 == 0 ? "Fizz" : _nextGenerator.Generate(number);
        }
    }
}