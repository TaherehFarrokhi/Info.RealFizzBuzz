namespace RealFizzBuzz.Core
{
    public interface ISequenceItemGenerator
    {
        string Generate(int number);
    }
}