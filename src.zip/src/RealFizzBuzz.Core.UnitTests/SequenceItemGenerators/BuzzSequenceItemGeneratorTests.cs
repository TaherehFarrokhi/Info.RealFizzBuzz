﻿using RealFizzBuzz.Core.SequenceItemGenerators;
using Xunit;

namespace RealFizzBuzz.Core.UnitTests.SequenceItemGenerators
{
    public class BuzzSequenceItemGeneratorTests
    {
        [Theory]
        [InlineData(5, "Buzz")]
        [InlineData(10, "Buzz")]
        public void GenerateReturnsBuzzWhenNumberIsMultiplyOf5(int number, string expected)
        {
            // Aquire
            var sut = new BuzzSequenceItemGenerator();

            // Act
            var output = sut.Generate(number);

            // Assert
            Assert.Equal(expected, output);
        }        
        
        [Theory]
        [InlineData(1, "Buzz")]
        [InlineData(15, "Buzz")]
        public void GenerateShouldntReturnsBuzzWhenNumberIsMultiplyOf15OrNotMultiplyOf5(int number, string notExpected)
        {
            // Aquire
            var sut = new BuzzSequenceItemGenerator();

            // Act
            var output = sut.Generate(number);

            // Assert
            Assert.NotEqual(notExpected, output);
        }
    }
}