using System.Linq;
using RealFizzBuzz.Core.SequenceItemGenerators;

namespace RealFizzBuzz.Core
{
    public class SequenceGenerator
    {
        private readonly ISequenceItemGenerator _sequenceItemGenerator;

        public SequenceGenerator()
        {
            _sequenceItemGenerator = new FizzBuzzSequenceItemGenerator();
        }
        
        public SequenceResult Generate(int lower, int upper)
        {
            if (lower > upper)
                return new SequenceResult(new string[]{});

            var sequence = Enumerable.Range(lower, upper).Select(GenerateSingle).ToArray();
            return new SequenceResult(sequence);
        }

        private string GenerateSingle(int number) 
        {
            return _sequenceItemGenerator.Generate(number);
        }
    }
}