namespace RealFizzBuzz.Core.SequenceItemGenerators
{
    public class BuzzSequenceItemGenerator : ISequenceItemGenerator
    {
        private readonly ISequenceItemGenerator _nextGenerator;

        public BuzzSequenceItemGenerator()
        {
            _nextGenerator = new FizzSequenceItemGenerator();
        }
        
        public string Generate(int number)
        {
            return number % 5 == 0 ? "Buzz" : _nextGenerator.Generate(number);
        }
    }
}